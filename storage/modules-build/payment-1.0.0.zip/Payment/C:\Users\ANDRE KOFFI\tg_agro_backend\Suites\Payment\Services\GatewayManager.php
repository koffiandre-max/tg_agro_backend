<?php

namespace Modules\Payment\Services;

use InvalidArgumentException;
use Modules\Payment\Gateways\CinetPayGateway;
use Modules\Payment\Gateways\FedaPayGateway;
use Modules\Payment\Gateways\PaymentGateway;
use Modules\Payment\Gateways\SimulateGateway;

/**
 * Résout les passerelles de paiement déclarées dans config("payment.gateways").
 */
class GatewayManager
{
    /**
     * Instance du driver demandé (ou de la passerelle par défaut).
     */
    public function driver(?string $name = null): PaymentGateway
    {
        $name = $name ?: (string) config('payment.default_gateway', 'simulate');
        $config = config("payment.gateways.{$name}");

        if (! is_array($config)) {
            throw new InvalidArgumentException("Passerelle de paiement inconnue : {$name}.");
        }

        return match ($config['driver'] ?? $name) {
            'simulate' => new SimulateGateway(),
            'fedapay' => new FedaPayGateway(),
            'cinetpay' => new CinetPayGateway(),
            default => throw new InvalidArgumentException(
                'Driver de paiement non supporté : '.($config['driver'] ?? $name).'.'
            ),
        };
    }

    /**
     * Liste des passerelles disponibles, pour l'affichage.
     *
     * @return array<string, string> name => label
     */
    public function available(): array
    {
        $list = [];

        foreach ((array) config('payment.gateways', []) as $name => $config) {
            $list[$name] = $config['label'] ?? $name;
        }

        return $list;
    }
}
